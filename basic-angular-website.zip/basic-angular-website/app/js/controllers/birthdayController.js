function birthdayController(birthdayService) {
  'ngInject';

  // ViewModel
  let self = this;
  self.details = birthdayService.getAll();
}

export default {
  name: 'birthdayController',
  fn: birthdayController
};
