function basicController(basicService) {
  'ngInject';

  // COMO ESTOU A LER UM JSON TENHO DE POR ESTE CÓDIGO!!!
  let self = this;
  basicService.getAll().then(function(lista){
    self.details = lista.data;
    //console.log("olá!!!");
  });

}

export default {
  name: 'basicController',
  fn: basicController
};
