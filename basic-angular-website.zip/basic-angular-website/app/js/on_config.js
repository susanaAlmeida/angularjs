function OnConfig($stateProvider, $locationProvider, $urlRouterProvider) {
  'ngInject';

  $locationProvider.html5Mode(true);
  $urlRouterProvider.otherwise('/');

  $stateProvider
  .state('Home', {
    url: '/',
    controller: 'ExampleCtrl as home',
    templateUrl: 'home.html',
    title: 'Home'
  })
  .state('basic',{
    url: '/basic',
    templateUrl: 'basic.html',
    controller: 'basicController',
    controllerAs: 'basic',
    title: 'Basic'
  })
  .state('basic-edit',{
    url: '/basic/:id/edit',
    templateUrl: 'basic-form.html',
    controller:'basicEditController',
    controllerAs:'basic',
    title:'Basic'
  })
  .state('basic-create',{
    url: '/basic/create',
    templateUrl: 'basic-form.html',
    controller:'basicCreateController',
    controllerAs:'basic',
    title:'Basic'
  })
  .state('basic-delete',{
    url: '/basic/:id/delete',
    controller:'bbasicDeleteController',
    controllerAs:'basic',
    title:'Basic'
  })
  .state('birthday',{
    url: '/birthday',
    templateUrl: 'birthday.html',
    controller: 'birthdayController',
    controllerAs: 'birthday',
    title: 'Birthday'
  })
  .state('birthday-create',{
    url: '/birthday/create',
    templateUrl: 'birthday-form.html',
    controller:'birthdayCreateController',
    controllerAs:'birthday',
    title:'Birthday'
  })
  .state('birthday-edit',{
    url: '/birthday/:id/edit',
    templateUrl: 'birthday-form.html',
    controller:'birthdayEditController',
    controllerAs:'birthday',
    title:'Birthday'
  })
  .state('birthday-delete',{
    url: '/birthday/:id/delete',
    controller:'birthdayDeleteController',
    controllerAs:'birthday',
    title:'Birthday'
  })
  ;



}

export default OnConfig;
