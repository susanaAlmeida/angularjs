'use strict';

import gulp from 'gulp';

gulp.task('deploy', ['prod'], function() {

  // Any deployment logic should go here

});